alert("Buenos días");
console.log("hola como estas")

let a=10;
let b=20; 

console.log("suma")

//Declaración de funcion
function saludo(){
    console.log("Hola estoy en la función");
}
//Invocar la función
saludo();
saludo();
saludo();
saludo();
saludo();
otrosaludo("Maria");
otrosaludo("Jose");
sumar(4,5);
console.log(suma);

let suma=sumar(4,5);
console.log(suma)

let calculoIgv=IGV(1000);
console.log("El IGV es "+calculoIgv)

let calculoArea=IGV(1000);
console.log("El IGV es "+calculoIgv)

function otrosaludo(nombre){
    console.log("Hola como estas "+nombre);
}
function sumar(num1,num2){
    return num1+num2
}
function IGV(ventas){
    return ventas*0.18
}
// function area_cuadrado(lado){
    return lado*lado
