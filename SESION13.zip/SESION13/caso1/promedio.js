function promedio(){
    var ep,ef,pt,pp,prom;
    ep=parseInt(prompt("Ingrese la nota del Examen Parcial"));
    ef=parseInt(prompt("Ingrese la nota del Examen Final"));
    pt=parseInt(prompt("Ingrese la nota del Promedio de Trabajos"));
    pp=parseInt(prompt("Ingrese la nota de Promedio de Practicas"));
    prom=(ep+ef+pt+pp)/4;
    if (prom>=13) {
        document.write("Su Promedio es: "+prom+"<br>"+"Esta APROBADO")
    } else {
        document.write("Su Promedio es: "+prom+"<br>"+ "Esta DESAPROBADO")
    }
}