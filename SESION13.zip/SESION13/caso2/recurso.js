function venta(){
    //Declara variables de ingreso

    var producto,precio,cantidad,st,igv,tps,tpd,tc;
    var mensaje;

    //Fase de lectura
    producto=prompt("Ingrese nombre producto");
    precio=parseFloat(prompt("Ingrese el precio unitario"));
    cantidad=parseInt(prompt("Ingrese la cantidad a comprar"));
    tc=parseInt(prompt("Ingrese el tipo de cambio"));

   // st=precio*cantidad
   // igv= st*0.18
   // tps= st+igv
   // tpd= tps/3


    //--------Invocación de funciones--------//
   st=subtotal(precio,cantidad);
   igv=xigv(st)
   tps=totalpagars(st,igv)
   tpd=totalpagard(tps,tc)
   mensaje=estado() 

//--------Declaración de funciones--------//
function subtotal(a,b){
    return a*b;
}
function xigv(c) {
    return c*0.18
}
function totalpagars(d,e) {
    return d+e
}
function totalpagard(f,g) {
    return f/g
}
function estado(h) {
    if (h>1000){
        return("Total a pagar Elevado")
    } else {
        return("Total a pagar Moderado")
    }
}

document.write("Producto: "+producto+"<br>")
document.write("Precio unit: "+precio+"<br>")
document.write("Cantidad: "+cantidad+"<br>")
document.write("Subtotal: "+st+"<br>")
document.write("IGV: "+igv+"<br>")
document.write("Total en soles: "+tps+"<br>")
document.write("Total en dolares: "+tpd+"<br>")
document.write("Estado: "+mensaje+"<br>")
}